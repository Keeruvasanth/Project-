<?php



// Grab User submitted information
$email = $_POST["username"];
$pass = $_POST["password"];

if($email=='abcd'&& $pass=='123')
echo "Connected successfully";
?>